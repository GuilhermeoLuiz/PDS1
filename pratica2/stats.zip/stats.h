//funcao para calcular a distribuicao de Laplace
float laplace(float x, float y, float b);

//funcao para realizar o calculo de Gumbel
float gumbel(float x, float y, float z);

//funcao para realizar o calculo de Cauchy
float cauchy(float x);