//Codigo de Guilherme Luiz - Pratica0 de PDS - 19/03/25
#include <stdlib.h>

int main() {
    system("ls");
    return 0;
}