//Codigo de Guilherme Luiz - Pratica0 de PDS - 19/03/25
#include <stdio.h>

int main() {
    printf("Guilherme Luiz Teixeira Gonzaga!\n");
    return 0;
}