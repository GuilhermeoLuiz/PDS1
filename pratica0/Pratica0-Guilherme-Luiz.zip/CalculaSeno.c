//Codigo de Guilherme Luiz - Pratica0 de PDS - 19/03/25
#include <stdio.h>
#include <math.h>

int main() {
    printf("Seno de 3.14: %f\n", sin(3.14));
    printf("Seno de 4.13: %f\n", sin(4.13));
    return 0;
}