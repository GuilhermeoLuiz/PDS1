//Codigo de Guilherme Luiz - Pratica0 de PDS - 19/03/25
#include <stdio.h>

int main() {
    printf("\a");
    return 0;
}