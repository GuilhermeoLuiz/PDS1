//funcao para somar 1 a um inteiro qualquer
void soma1(int* p);

//funcao para troca valores de float
void troca(float* end_valor_1, float* end_valor_2);

//retorna o ddd de um numero de 11 digitos
int ddd(long long int num);